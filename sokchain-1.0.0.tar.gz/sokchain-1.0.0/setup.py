# setup.py

import os
from setuptools import setup, find_packages

# --- Đọc nội dung file README.md để làm mô tả dài ---
# Đây là một thực hành tốt để mô tả của bạn trên PyPI (nếu có) được đẹp mắt.
try:
    with open(os.path.join(os.path.dirname(__file__), 'README.md'), encoding='utf-8') as f:
        long_description = f.read()
except FileNotFoundError:
    long_description = 'Một blockchain đơn giản được vận hành bởi một Hội đồng AI (AI Council).'

# --- ĐỊNH NGHĨA CÁC THÔNG SỐ CHÍNH ---
setup(
    # === THÔNG TIN CƠ BẢN ===
    name='sokchain',  # Tên gói khi bạn cài đặt bằng pip (pip install sokchain)
    version='1.0.0',   # Phiên bản của dự án. Tuân theo Semantic Versioning (Major.Minor.Patch)
    author='Your Name', # Thay bằng tên của bạn
    author_email='your.email@example.com', # Email của bạn
    description='Một blockchain thử nghiệm được điều khiển bởi các tác nhân AI.', # Mô tả ngắn gọn
    long_description=long_description, # Mô tả dài, thường lấy từ file README
    long_description_content_type='text/markdown', # Định dạng của mô tả dài
    url='https://github.com/your_username/sokchain', # URL đến trang GitHub của dự án (nếu có)
    license='MIT', # Giấy phép của mã nguồn (MIT là một lựa chọn phổ biến và dễ dãi)
    
    # === CẤU HÌNH GÓI ===
    # find_packages() sẽ tự động tìm tất cả các thư mục con có file __init__.py
    # và coi chúng là các gói cần đóng gói. Trong trường hợp này, nó sẽ tìm thấy 'sok'.
    packages=find_packages(exclude=['app', 'tests*']),
    
    # Chỉ định các file không phải code Python cần được đưa vào gói
    # Ví dụ: nếu bạn có các file template hoặc dữ liệu mặc định trong 'sok'
    # package_data={
    #     'sok': ['templates/*.html', 'data/*.json'],
    # },
    
    # === CÁC THƯ VIỆN PHỤ THUỘC ===
    # Liệt kê tất cả các thư viện bên ngoài mà dự án của bạn cần.
    # Khi người dùng chạy 'pip install sokchain-1.0.0.whl', pip sẽ tự động
    # cài đặt tất cả các thư viện này.
    install_requires=[
        'requests>=2.20.0',
        'Flask>=2.0.0',
        'Flask-Cors>=3.0.0',
        'waitress>=2.0.0',
        'cryptography>=3.0.0',
        'rich>=10.0.0', # Cho các công cụ CLI
        'pynput',         # Cho SokWorker_Service (nếu bạn đóng gói nó)
        'pywin32; platform_system=="Windows"', # Chỉ cài trên Windows
        'setuptools',
        'wheel',
        'build'
    ],
    
    # === YÊU CẦU VỀ MÔI TRƯỜNG ===
    python_requires='>=3.10', # Yêu cầu phiên bản Python tối thiểu
    
    # === PHÂN LOẠI ===
    # Giúp người khác tìm thấy gói của bạn trên PyPI (Python Package Index)
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Operating System :: OS Independent',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'Topic :: System :: Distributed Computing',
    ],
    
    # === ENTRY POINTS (Tùy chọn nâng cao) ===
    # Cho phép bạn tạo các lệnh có thể chạy trực tiếp từ terminal sau khi cài đặt
    # Ví dụ, sau khi cài, người dùng có thể gõ 'sok-wallet' thay vì 'python cli_wallet.py'
    # entry_points={
    #     'console_scripts': [
    #         'sok-node=app.run_node:main',
    #         'sok-miner=app.run_miner_autho:main',
    #         'sok-wallet=app.cli_wallet:main',
    #     ],
    # },
)
